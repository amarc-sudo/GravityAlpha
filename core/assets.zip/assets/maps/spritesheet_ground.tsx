<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.2" name="spritesheet_ground" tilewidth="64" tileheight="64" tilecount="128" columns="8">
 <image source="../spritesheet_ground.png" width="512" height="1024"/>
</tileset>
