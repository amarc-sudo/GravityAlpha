<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.2" name="spritesheet_items" tilewidth="64" tileheight="64" tilecount="32" columns="8">
 <image source="../spriteasset/spritesheet_items.png" width="512" height="256"/>
</tileset>
