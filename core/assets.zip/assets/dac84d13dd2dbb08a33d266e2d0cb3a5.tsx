<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.2" name="dac84d13dd2dbb08a33d266e2d0cb3a5" tilewidth="64" tileheight="64" tilecount="336" columns="21">
 <image source="../../../dac84d13dd2dbb08a33d266e2d0cb3a5.png" width="1388" height="1076"/>
</tileset>
